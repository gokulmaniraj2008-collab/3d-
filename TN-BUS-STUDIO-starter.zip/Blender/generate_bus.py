import bpy, math, os
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
def mat(name, color, metallic=0, roughness=.55):
 m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
 p=m.node_tree.nodes.get("Principled BSDF"); p.inputs["Base Color"].default_value=(*color,1); p.inputs["Metallic"].default_value=metallic; p.inputs["Roughness"].default_value=roughness
 return m
green=mat("TN transport green",(.12,.34,.18)); cream=mat("Cream paint",(.82,.79,.63))
black=mat("Rubber and grille",(.025,.028,.03)); glass=mat("Dark glass",(.045,.10,.12),.15,.16)
metal=mat("Metal",(.48,.49,.47),.7); amber=mat("Amber signals",(.95,.38,.03)); white=mat("Headlamp glass",(.86,.88,.79))
def cube(name,loc,scale,material,bevel=0):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object;o.name=name;o.dimensions=scale
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel: mod=o.modifiers.new("Soft edges","BEVEL");mod.width=bevel;mod.segments=2;o.modifiers.new("Weighted normals","WEIGHTED_NORMAL")
 o.data.materials.append(material);return o
def cylinder(name,loc,r,depth,material,rotation=(0,0,0),vertices=32):
 bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=r,depth=depth,location=loc,rotation=rotation)
 o=bpy.context.object;o.name=name;o.data.materials.append(material);return o
# X width, Y length, Z height; front points toward negative Y.
cube("Lower green body",(0,0,1.48),(2.42,10.3,1.55),green,.10)
cube("Upper cream cabin",(0,0,2.64),(2.42,10.3,.87),cream,.08)
cube("Roof",(0,0,3.16),(2.48,10.4,.18),cream,.09)
cube("Green waist stripe",(0,0,2.11),(2.45,10.32,.16),green)
cube("Chassis",(0,0,.72),(2.0,9.9,.19),black)
# Side windows
for side in (-1,1):
 x=side*1.223
 for i in range(8):
  y=-4.45+i*1.22
  cube(f"Side window {side} {i}",(x,y,2.67),(.025,1.03,.63),glass,.025)
  cube(f"Window pillar {side} {i}",(x+side*.012,y+.55,2.67),(.05,.055,.70),cream)
 # mirrors and supports
 cube(f"Mirror stalk {side}",(side*1.38,-5.14,2.58),(.30,.055,.05),metal)
 cube(f"Mirror {side}",(side*1.53,-5.15,2.56),(.20,.09,.37),black,.025)
 # two axles, with rear dual wheel pairs
 for y in (-3.55,3.05):
  for offset in ((0,.18) if y>0 else (0,)):
   xx=side*(1.13-offset)
   cylinder(f"Tyre {side} {y} {offset}",(xx,y,.59),.56,.19,black,(0,math.pi/2,0))
   cylinder(f"Hub {side} {y} {offset}",(side*(abs(xx)+.11),y,.59),.24,.015,metal,(0,math.pi/2,0))
# Front face
cube("Front destination sign",(0,-5.175,2.94),(1.85,.045,.24),green)
cube("Windshield",(0,-5.176,2.53),(2.04,.055,.62),glass,.04)
cube("Windshield middle bar",(0,-5.216,2.53),(.045,.055,.66),cream)
cube("Front cream band",(0,-5.18,1.94),(2.25,.055,.31),cream)
cube("Front grille",(0,-5.195,1.32),(1.40,.055,.49),black,.02)
for i in range(5):
 cube(f"Grille slat {i}",(0,-5.23,1.14+i*.085),(1.31,.025,.018),metal)
for side in (-1,1):
 for j in range(2):
  # cylinders face forward (local z rotated onto y)
  cylinder(f"Headlight {side} {j}",(side*(.78+j*.18),-5.24,1.18),.075,.035,white,(math.pi/2,0,0))
 cube(f"Indicator {side}",(side*1.01,-5.24,1.47),(.18,.035,.10),amber)
cube("Front bumper",(0,-5.27,.80),(2.50,.22,.18),metal,.04)
cube("Rear bumper",(0,5.27,.80),(2.50,.22,.18),metal,.04)
# Simple door outline on left, near front
cube("Entrance door glass",(-1.233,-3.92,2.55),(.028,.67,.69),glass)
cube("Entrance door seam",(-1.255,-3.92,1.67),(.03,.025,1.15),black)
# Floor and world
cube("Display ground",(0,0,-.055),(15,19,.08),mat("Ground",(.30,.32,.30)))
world=bpy.context.scene.world
world.color=(.20,.20,.20)
# Camera and area light
bpy.ops.object.camera_add(location=(12,-17,10));cam=bpy.context.object
direction=Vector((0,0,1.65))-cam.location;cam.rotation_euler=direction.to_track_quat('-Z','Y').to_euler()
bpy.context.scene.camera=cam
bpy.ops.object.light_add(type='AREA',location=(2,-6,10));bpy.context.object.data.energy=2500;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=8
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=32
scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100
out=os.path.abspath(os.environ.get("BUS_OUTPUT","Exports"));os.makedirs(out,exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(out,"TN_Bus.blend"))
# Export only model objects; exclude ground/camera/light
bpy.ops.object.select_all(action='DESELECT')
for o in bpy.context.scene.objects:
 if o.type=='MESH' and o.name!="Display ground":o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(out,"TN_Bus.glb"),export_format='GLB',use_selection=True)
scene.render.filepath=os.path.join(out,"TN_Bus_preview.png")
bpy.ops.render.render(write_still=True)
