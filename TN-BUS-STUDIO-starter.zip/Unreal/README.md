Future Unreal project. Import a compatible bus asset when desktop Unreal Engine is available.
