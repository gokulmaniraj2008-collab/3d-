# TN BUS STUDIO 🚌

Phone-first, free starter project. Blender generates a **stylized first draft**, not an exact photo reconstruction.

## On Android
1. Create a GitHub repository named `TN-BUS-STUDIO`.
2. Upload the contents of this ZIP (including `.github/workflows/build-bus.yml`) using GitHub's web interface, or upload via a Git client that preserves folders.
3. Open **Actions → Generate TN Bus 3D → Run workflow**.
4. When the run succeeds, open its **Artifacts → TN-Bus-3D** and download the ZIP.
5. Unzip to obtain `TN_Bus.blend`, `TN_Bus.glb`, and `TN_Bus_preview.png`.

GitHub Actions availability/usage and artifact retention depend on your account and current GitHub terms. Public repository standard hosted runners generally have no Actions minute charges, subject to abuse and platform limits. Do not commit private information.

## Notes
- The procedural model uses metres; X = width, Y = length, Z = height.
- Edit `Blender/generate_bus.py` to improve the shape and details.
- Godot and Unreal folders are reserved for later engine-specific projects.
- GLB is the portable asset; `.blend` is the editable source.
