Future Godot simulator project. Import Exports/TN_Bus.glb after downloading the generated artifact.
